# ScamShield + Gmail (read-only)

Paste-in scam checking works with no setup. Gmail scanning is **off until you add your own Google credentials**. The UI shows the true status (backend not running / not configured / not connected / connected).

> Not tested against a live Google account by the author. Expect to debug your Google Cloud setup.

## Run it
```bash
npm install
cp .env.example .env     # then fill in the values
npm start                # http://localhost:3000
```

## Google Cloud setup (about 10 minutes)
1. Go to https://console.cloud.google.com and create a project.
2. **APIs & Services → Library**: enable the **Gmail API**.
3. **OAuth consent screen**: user type *External*, keep it in **Testing**, and add your Gmail address under **Test users**.
4. Add the scopes `gmail.readonly` and `userinfo.email`.
5. **Credentials → Create credentials → OAuth client ID → Web application**.
   Authorized redirect URI: `http://localhost:3000/auth/google/callback`
6. Put the client ID and secret in `.env`. Set `SESSION_SECRET` to a long random string.
7. Restart, open http://localhost:3000, go to **Settings → Connect Gmail**, then use the **Inbox** page.

While in Testing mode only listed test users can sign in (fine for a hackathon). Google will show an "unverified app" warning; that's expected.

## How it works
- `server.js`: Express + `googleapis`. OAuth with a CSRF `state` check, `access_type=online` (no refresh token stored), and read-only scope.
- `GET /api/status`, `GET /auth/google`, `GET /auth/google/callback`, `GET /api/emails?max=15`, `POST /auth/logout` (revokes the token).
- Tokens are kept in the server's session memory only. Emails are fetched on request, not stored or logged.
- `public/index.html`: the UI. Email text is analyzed in the browser by the same rule-based `Analyzer` (no AI).

## Before real users
- Use HTTPS and set `BASE_URL` to it (register that redirect URI too).
- Replace the default in-memory session store (Redis etc.).
- Gmail read access is a **restricted scope**: public launch requires Google's app verification and a security assessment.
- Add rate limiting; email content is sensitive, so keep it out of logs.
- If you connect a hosted AI model to analyze emails, update the privacy text in Settings first, because email content would then leave your server.

## Optional: AI second opinion
Adds an **Ask the AI** button under each result. It stays off until you set `ANTHROPIC_API_KEY`.
1. Create an API key at https://console.anthropic.com (usage is billed to your account).
2. Add `ANTHROPIC_API_KEY=...` to `.env` (optionally `ANTHROPIC_MODEL`, default `claude-haiku-5-5`) and restart.
3. Check a message, then click **Ask the AI**.

Notes: text is sent to the Anthropic API only when the user clicks the button, and the key stays on the server. The endpoint is rate-limited (15 per minute per IP) and requires a custom header. The model is told to treat the text as untrusted data, but AI can still be wrong or manipulated, so present it as a second opinion, not a verdict. If you deploy this, make sure the privacy text matches what you actually do with data.

## Using Groq instead of Anthropic
Add `GROQ_API_KEY=gsk_...` to `.env` (no quotes) and restart. The terminal should print `AI second opinion: Groq (...)`. The default model is `llama-3.3-70b-versatile`; change it with `GROQ_MODEL` if Groq retires or renames models (see console.groq.com). If both Anthropic and Groq keys are set, Anthropic is used unless you set `AI_PROVIDER=groq`. Free tiers have rate limits, and you should read Groq's data terms before sending real users' messages.
